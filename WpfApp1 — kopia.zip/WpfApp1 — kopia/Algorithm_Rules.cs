﻿namespace WpfApp1
{
    public enum Algorithm_Rules
    {
        Free,   //The cell hasn't been clicked   
        Nought, //The cell is a O
        Cross   //The cell is an X
       
    }
}
